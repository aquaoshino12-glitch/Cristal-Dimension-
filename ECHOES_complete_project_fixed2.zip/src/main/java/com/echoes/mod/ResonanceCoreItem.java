package com.echoes.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ResonanceCoreItem extends Item {
    public ResonanceCoreItem(Settings settings) { super(settings); }

    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && world instanceof ServerWorld server) {
            Box area = user.getBoundingBox().expand(8.0);
            for (Entity target : world.getEntitiesByClass(Entity.class, area, e -> e != user && e.isAlive())) {
                Vec3d away = target.getPos().subtract(user.getPos());
                if (away.lengthSquared() < 0.001) away = new Vec3d(0, 1, 0);
                target.addVelocity(away.normalize().multiply(1.4).add(0, 0.35, 0));
                target.velocityModified = true;
            }
            server.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, user.getSoundCategory(), 0.8f, 1.15f);
            server.spawnParticles(net.minecraft.particle.ParticleTypes.SONIC_BOOM, user.getX(), user.getY()+1, user.getZ(), 1, 0, 0, 0, 0);
            user.getItemCooldownManager().set(this, 80);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
