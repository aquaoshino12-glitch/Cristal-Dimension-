package com.echoes.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public class EchoesMod implements ModInitializer {
    public static final String MOD_ID = "echoes";
    public static final Item ECHO_CRYSTAL = registerItem("echo_crystal", new Item(new Item.Settings()));
    public static final Item RESONANCE_CORE = registerItem("resonance_core", new ResonanceCoreItem(new Item.Settings().maxCount(1)));
    public static final Block ECHO_BLOCK = Registry.register(Registries.BLOCK, id("echo_block"),
        new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).sounds(BlockSoundGroup.AMETHYST_BLOCK).strength(3.0f)));
    public static final Item ECHO_BLOCK_ITEM = registerItem("echo_block", new BlockItem(ECHO_BLOCK, new Item.Settings()));

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, id(name), item);
    }
    public static Identifier id(String name) { return Identifier.of(MOD_ID, name); }

    @Override public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> entries.add(ECHO_CRYSTAL));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(RESONANCE_CORE));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> entries.add(ECHO_BLOCK_ITEM));
    }
}
