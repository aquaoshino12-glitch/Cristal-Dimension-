# ECHOES — Les Échos (Fabric 1.21.1)

Prototype source : Cristal d’Écho, bloc lumineux et Cœur de Résonance (onde de choc, recul, dégâts légers, particules et sons vanilla).

## Compilation mobile via GitHub Actions
1. Crée un dépôt GitHub et téléverse tous les fichiers du projet.
2. Ouvre l’onglet Actions et autorise les workflows si GitHub te le demande.
3. Lance `Build ECHOES` avec Run workflow ou pousse un commit.
4. Une fois terminé, ouvre le run et télécharge `ECHOES-mod-jar` dans Artifacts.
5. Dézippe l’Artifact : le JAR mod est dans `build/libs` (prends le JAR normal, pas `-sources`).

Ce prototype n'est pas encore une update complète : génération de structure, créature/IA et sons originaux sont les prochaines étapes. Compilation non testée dans cet environnement.
