package com.echoes.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class EchoesMod implements ModInitializer {
    public static final String MOD_ID = "echoes";
    public static final Item ECHO_CRYSTAL = Registry.register(Registries.ITEM, id("echo_crystal"), new Item(new FabricItemSettings()));
    public static final Item RESONANCE_CORE = Registry.register(Registries.ITEM, id("resonance_core"), new ResonanceCoreItem(new FabricItemSettings().maxCount(1)));
    public static final Block ECHO_BLOCK = Registry.register(Registries.BLOCK, id("echo_block"), new Block(FabricBlockSettings.copyOf(Blocks.AMETHYST_BLOCK).strength(3.0f).luminance(7)));
    public static final Item ECHO_BLOCK_ITEM = Registry.register(Registries.ITEM, id("echo_block"), new BlockItem(ECHO_BLOCK, new FabricItemSettings()));
    public static final SoundEvent RESONANCE_SOUND = Registry.register(Registries.SOUND_EVENT, id("resonance"), SoundEvent.of(id("resonance")));
    public static Identifier id(String name) { return Identifier.of(MOD_ID, name); }
    @Override public void onInitialize() { System.out.println("[ECHOES] Les Échos chargés !"); }
}
