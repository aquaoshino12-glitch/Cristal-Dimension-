package com.echoes.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.ItemUsage;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class ResonanceCoreItem extends Item {
    public ResonanceCoreItem(Settings settings) { super(settings); }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world instanceof ServerWorld serverWorld) {
            Vec3d center = player.getPos();
            Box area = new Box(center.x-8, center.y-4, center.z-8, center.x+8, center.y+4, center.z+8);
            for (Entity e : world.getOtherEntities(player, area)) {
                if (e instanceof LivingEntity living && living.isAlive()) {
                    Vec3d dir = living.getPos().subtract(center);
                    if (dir.lengthSquared() < 0.01) dir = new Vec3d(0,0,1);
                    dir = dir.normalize().multiply(1.65).add(0,0.55,0);
                    living.addVelocity(dir.x, dir.y, dir.z);
                    living.velocityModified = true;
                    living.damage(world.getDamageSources().playerAttack(player), 2.0f);
                }
            }
            serverWorld.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.4f, 0.65f);
            serverWorld.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.65f, 1.7f);
            serverWorld.spawnParticles(ParticleTypes.END_ROD, center.x, center.y+1, center.z, 70, 2.8, 1.1, 2.8, 0.08);
            serverWorld.spawnParticles(ParticleTypes.SCULK_SOUL, center.x, center.y+0.6, center.z, 45, 2.2, 0.8, 2.2, 0.07);
            serverWorld.spawnParticles(ParticleTypes.POOF, center.x, center.y+1, center.z, 30, 2, 1, 2, 0.06);
            if (!player.getAbilities().creativeMode) stack.decrement(1);
        }
        player.getItemCooldownManager().set(this, 80);
        return TypedActionResult.success(stack, world.isClient);
    }
}
